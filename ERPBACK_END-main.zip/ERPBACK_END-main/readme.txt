
        Api end points   
Method	Endpoint	Purpose
POST	/api/signup	Register a user
POST	/api/login	Login a user

